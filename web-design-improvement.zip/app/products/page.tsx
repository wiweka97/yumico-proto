import type { Metadata } from 'next'
import { ArrowUpRight } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { ProductsCatalogue } from '@/components/products-catalogue'
import { CustomPrint } from '@/components/custom-print'
import { primaryWhatsapp } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Products | Yumico Bali Food Packaging',
  description:
    'Browse Yumico’s full range of food packaging in Bali: kraft & white paper, bagasse, corn starch, aluminium, bakery packaging, candles and hotel supplies.',
}

export default function ProductsPage() {
  return (
    <>
      <SiteHeader />
      <main>
        <section className="bg-primary text-primary-foreground">
          <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-16 md:flex-row md:items-end md:justify-between md:px-8 md:py-24">
            <div className="max-w-2xl">
              <p className="text-sm font-medium uppercase tracking-widest text-accent">Product catalogue</p>
              <h1 className="mt-4 text-balance font-serif text-4xl font-medium leading-tight tracking-tight md:text-6xl">
                Packaging for every menu, in stock in Bali.
              </h1>
              <p className="mt-5 max-w-xl text-pretty leading-relaxed text-primary-foreground/80">
                Eleven categories, hundreds of sizes. Pick what you need and we&apos;ll quote you on WhatsApp,
                with delivery across Bali.
              </p>
            </div>
            <a
              href={primaryWhatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 self-start rounded-full bg-accent px-6 py-3 text-sm font-semibold text-accent-foreground transition-opacity hover:opacity-90 md:self-auto"
            >
              Get the full price list
              <ArrowUpRight className="size-4" aria-hidden="true" />
            </a>
          </div>
        </section>
        <ProductsCatalogue />
        <CustomPrint />
      </main>
      <SiteFooter />
    </>
  )
}
